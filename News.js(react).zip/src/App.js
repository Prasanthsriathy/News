import React from 'react';
import App2 from './App2';


function App() {
  return (
    <div>

<App2/>
    </div>
  )
}

export default App